/**
 *
 * @author Prof_C313
 */
public class Test {
    public static void main(String[] args) {
        Fen01 f01= new Fen01();
        Fen02 f02= new Fen02();
    }
}
