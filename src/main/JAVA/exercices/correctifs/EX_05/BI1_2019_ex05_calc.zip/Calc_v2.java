
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing.*;

/**
 *
 * @author Dominique
 */
public class Calc_v2 extends JFrame implements ActionListener {

  // ----------------------------------------------------------------
  // variables et constantes
  // ----------------------------------------------------------------
  // rootPane reprend MenuBar et ContentPane
  private final JPanel contentPane = (JPanel) getContentPane();

  private final JTextField txtNbre1 = new JTextField();
  private final JLabel lblOperateur = new JLabel("+");
  private final JTextField txtNbre2 = new JTextField();
  private final JLabel lblEgal = new JLabel("=");
  private final JTextField txtReponse = new JTextField();
  private final JButton btnReset = new JButton("Reset");
  private final JButton btnCalc = new JButton("Calculer");

  // ----------------------------------------------------------------
  // constructeurs
  // ----------------------------------------------------------------
  public Calc_v2() {
    initFenetre();  // initialiser les composants de la fenêtre
    setVisible(true);  // afficher la fenêtre
  }

  // ----------------------------------------------------------------
  // initialisation de la fenêtre et des composants
  // ----------------------------------------------------------------
  private void initFenetre() {
    // position et paramètres de la fenêtre
    setDefaultCloseOperation(EXIT_ON_CLOSE); // fermeture de l'application
    setLayout(null);  // layout null = positionnement en absolu
    setBounds(400, 100, 250, 150); // position et taille de la fenêtre
    setTitle("Calc_v2");

    // position et paramètres des différents éléments
    txtNbre1.setBounds(10, 10, 50, 20);

    lblOperateur.setBounds(70, 10, 10, 20);

    txtNbre2.setBounds(90, 10, 50, 20);

    lblEgal.setBounds(150, 10, 10, 20);

    txtReponse.setBounds(170, 10, 50, 20);
    //txtReponse.setEditable(false);
    txtReponse.setEnabled(false);

    btnReset.setBounds(10, 50, 100, 30);

    btnCalc.setBounds(120, 50, 100, 30);

    // comportement des différents éléments
    btnCalc.addActionListener(this);  // la fenêtre traite les évènements
    btnCalc.setActionCommand("Calculer");
    btnCalc.setMnemonic('C');  // Alt-C
    //rootPane.setDefaultButton(btnCalc);  // ENTER

    btnReset.addActionListener(this);  // la fenêtre traite les évènements
    btnReset.setActionCommand("Reset");
    btnReset.setMnemonic('R');  // Alt-R

    // ajout des différents éléments
    contentPane.add(txtNbre1);
    contentPane.add(lblOperateur);
    contentPane.add(txtNbre2);
    contentPane.add(lblEgal);
    contentPane.add(txtReponse);
    contentPane.add(btnReset);
    contentPane.add(btnCalc);
  }

  // ----------------------------------------------------------------
  // gestion des évènements (Action)
  // ----------------------------------------------------------------
  @Override
  public void actionPerformed(ActionEvent e) {
    //e représente l'évènement déclencheur
    String action = e.getActionCommand();
    switch (action) {
      case "Calculer":
        calculer();
        break;
      case "Reset":
        remiseAZero();
        break;
    }
  }

  // ----------------------------------------------------------------
  // méthodes
  // ----------------------------------------------------------------
  private void calculer() {
    // gestion erreurs
    try {
      double n1 = Double.parseDouble(txtNbre1.getText());
      double n2 = Double.parseDouble(txtNbre2.getText());
      double rep = n1 + n2;

      txtReponse.setText(String.valueOf(rep));

    } catch (NumberFormatException e) {
      // erreur de transformation d'un texte en double
      txtReponse.setText("Erreur !");
    }

  }

  private void remiseAZero() {
    txtNbre1.setText("");
    txtNbre2.setText("");
    txtReponse.setText("");

    txtNbre1.requestFocusInWindow();  // donner le focus
  }
  // ----------------------------------------------------------------
}
