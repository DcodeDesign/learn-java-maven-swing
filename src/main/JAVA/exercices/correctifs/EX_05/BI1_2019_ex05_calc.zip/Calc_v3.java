
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.TextEvent;
import java.awt.event.TextListener;
import javax.swing.*;

/**
 *
 * @author Dominique
 */
public class Calc_v3 extends JFrame implements ActionListener, KeyListener {

  // ----------------------------------------------------------------
  // variables et constantes
  // ----------------------------------------------------------------
  // rootPane reprend MenuBar et ContentPane
  private final JPanel contentPane = (JPanel) getContentPane();

  private final JTextField txtNbre1 = new JTextField();
  private final JLabel lblOperateur = new JLabel("+");
  private final JTextField txtNbre2 = new JTextField();
  private final JLabel lblEgal = new JLabel("=");
  private final JTextField txtReponse = new JTextField();
  private final JButton btnReset = new JButton("Reset");

  // ----------------------------------------------------------------
  // constructeurs
  // ----------------------------------------------------------------
  public Calc_v3() {
    initFenetre();  // initialiser les composants de la fenêtre
    setVisible(true);  // afficher la fenêtre
  }

  // ----------------------------------------------------------------
  // initialisation de la fenêtre et des composants
  // ----------------------------------------------------------------
  private void initFenetre() {
    // position et paramètres de la fenêtre
    setDefaultCloseOperation(EXIT_ON_CLOSE); // fermeture de l'application
    setLayout(null);  // layout null = positionnement en absolu
    setBounds(700, 100, 250, 150); // position et taille de la fenêtre
    setTitle("Calc_v3");

    // position et paramètres des différents éléments
    txtNbre1.setBounds(10, 10, 50, 20);

    lblOperateur.setBounds(70, 10, 10, 20);

    txtNbre2.setBounds(90, 10, 50, 20);

    lblEgal.setBounds(150, 10, 10, 20);

    txtReponse.setBounds(170, 10, 50, 20);
    txtReponse.setEnabled(false);

    btnReset.setBounds(10, 50, 100, 30);

    // comportement des différents éléments
    txtNbre1.addKeyListener(this);

    txtNbre2.addKeyListener(this);

    btnReset.addActionListener(this);  // la fenêtre traite les évènements
    btnReset.setActionCommand("Reset");

    // ajout des différents éléments
    contentPane.add(txtNbre1);
    contentPane.add(lblOperateur);
    contentPane.add(txtNbre2);
    contentPane.add(lblEgal);
    contentPane.add(txtReponse);
    contentPane.add(btnReset);
  }

  // ----------------------------------------------------------------
  // gestion des évènements (Action)
  // ----------------------------------------------------------------
  @Override
  public void actionPerformed(ActionEvent e) {
    //e représente l'évènement déclencheur
    String action = e.getActionCommand();
    switch (action) {
      case "Calculer":
        calculer();
        break;
      case "Reset":
        remiseAZero();
        break;
    }
  }

  @Override
  public void keyReleased(KeyEvent e) {
    //e représente l'évènement déclencheur
    Object source = e.getSource();  // composant à l'origine de l'evènement
    if (source == txtNbre1 || source == txtNbre2) {
      calculer();
    }
  }

  @Override
  public void keyTyped(KeyEvent e) {
    // pas utilisé
  }

  @Override
  public void keyPressed(KeyEvent e) {
    // pas utilisé
  }

  // ----------------------------------------------------------------
  // méthodes
  // ----------------------------------------------------------------
  private void calculer() {
    // gestion erreurs
    try {
      double n1 = Double.parseDouble(txtNbre1.getText());
      double n2 = Double.parseDouble(txtNbre2.getText());
      double rep = n1 + n2;

      txtReponse.setText(String.valueOf(rep));

    } catch (NumberFormatException e) {
      // erreur de transformation d'un texte en double
      txtReponse.setText("Erreur !");
    }

  }

  private void remiseAZero() {
    txtNbre1.setText("");
    txtNbre2.setText("");
    txtReponse.setText("");

    txtNbre1.requestFocusInWindow();  // donner le focus
  }
  // ----------------------------------------------------------------

}
