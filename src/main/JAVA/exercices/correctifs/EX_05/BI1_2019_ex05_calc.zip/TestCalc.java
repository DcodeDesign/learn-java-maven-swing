
/**
 *
 * @author Dominique
 */
public class TestCalc {

  public static void main(String[] args) {
    Calc_v1 calc1 = new Calc_v1();

    Calc_v2 calc2 = new Calc_v2();

    Calc_v3 calc3 = new Calc_v3();

    Calc_v4 calc4 = new Calc_v4();
  }
}
